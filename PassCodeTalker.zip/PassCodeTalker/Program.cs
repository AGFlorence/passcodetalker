﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace PassCodeTalker
{

    class Program
    {

        public string GET { get; private set; }

        /*
         @ function main()
         * the main function for the overall programs processes
         * variables included are:
         * string UN = the variable the username input is saved to
         * string PW = the variable the password input is saved to
         * bool PwV = the variable for deciding whether the entered
           is valid this is parsed as a parameter to the @passwordValidator()         
         * string ID = the users unique record identify
         * 
         * 
         * 
         */

        public static void Main()
        {
            string userEntry;
            bool Exit = false;

            while (Exit == false)
            {
                Console.Write("do you need to make an account (YES/NO): ");
                userEntry = Console.ReadLine();

                if (userEntry == "yes" || userEntry == "YES")
                {
                    newUserAccountRegister.newAccount();
                    Console.Write("do you wish to continue: ");
                    userEntry = Console.ReadLine();
                    if (userEntry == "yes" || userEntry == "YES")
                    {
                        Exit = false;
                    }
                    else
                    {
                        Exit = true;
                    }
                }
                else if (userEntry == "no" || userEntry == "NO")
                {
                    Exit = true;
                }
            }
        } 
    }
}
