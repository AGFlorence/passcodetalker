﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PassCodeTalker
{
    public class newUserAccountRegister
    {
        public static void newAccount()
        {
            string UN;
            string PW;
            bool PwV = false;
            bool IID = false;
            string ID;
            string fName;
            string lName;

            /*
             @ while(PwV == false)
             * a loop that checks the condition at its start.
             * it takes in the username and password through user inputs.
             * it then saves them to the appropriate variables.
             * then it validates the password using the @PasswordValidator(PW)
               and sets PwV accordingly.
             * finally it utilises an if statement based on the PwV value after
               @PasswordValidator(PW) and confirms to the user A) their account
               has been created || B) that their password was invalid.
             */
            while (PwV == false)
            {
                Console.WriteLine("please enter a username & password");
                Console.Write("username: ");
                UN = Console.ReadLine();
                Console.Write("Password: ");
                PW = Console.ReadLine();

                PwV = PasswordValidator(UN, PW);
                if (PwV == false)
                {
                    Console.WriteLine("your password was invalid");
                    Console.WriteLine("your password needs to be between 8 & 12 characters");
                    Console.WriteLine("please re-enter username + Password");
                }
                else
                {
                    Console.Write("your account has been created");
                    Console.ReadLine();
                    ID = genUserID();
                    while (IID == false)
                    {
                        ID = genUserID();
                        IID = idIsUnique(ID);
                        if (IID == true)
                        {
                            saveID(ID);
                            saveUserName(UN);
                            savePassword(PW);
                            Console.WriteLine("please enter your First Name");
                            Console.Write("First Name:");
                            fName = Console.ReadLine();
                            Console.WriteLine("please enter your Last Name");
                            Console.Write("Last Name:");
                            lName = Console.ReadLine();
                            saveNames(fName, lName);
                            completeFile();

                        }
                        else
                        {
                            ID = genUserID();
                            IID = idIsUnique(ID);
                        }
                    }
                }
            }
        }
        /*
         @ PasswordValidator()
         * this function is designed to evaluate the length of the Password
           inputted by the user.
         * it clarifies whether the Password Length is between 8 - 12 characters.
         * if it is outside this range it will output not a valid password &
           PwV will remain constant and then be returned.
         * if it is within this range it will switch PwV to true and then be
           returned.
         */
        public static bool PasswordValidator(string userName, string passWord)
        {
            bool PwV = false;

            if (passWord.Length < 8)
            {
                Console.WriteLine("Not a Valid password");
                PwV = false;
            }

            else if (passWord.Length > 12)
            {
                Console.WriteLine("Not a Valid password");
                PwV = false;
            }
            else
            {
                PwV = true;
            }
            return PwV;
        }
        /*
         @ function genUserID()
         * this function is designed to generate a UserID as the name of the users
           account record.
         * it generates a random 6 digit number to do this
         * if the number generated is < 6 digits it will append a series of "0"
           to the front of the number to turn it into a 6 digit number
         * finally it will return the UserID to main().
         */
        public static string genUserID()
        {
            string userID;
            const string ap5 = "00000";
            const string ap4 = "0000";
            const string ap3 = "000";
            const string ap2 = "00";
            const string ap1 = "0";
            string apdTo;
            Random RID = new Random();
            int intID = RID.Next(1, 1000000);

            if (intID < 10)
            {
                apdTo = ap5 + Convert.ToString(intID);
                userID = apdTo;
                return userID;
            }

            else if (intID >= 10 & intID < 100)
            {
                apdTo = ap4 + Convert.ToString(intID);
                userID = apdTo;
                return userID;
            }

            else if (intID >= 100 & intID < 1000)
            {
                apdTo = ap3 + Convert.ToString(intID);
                userID = apdTo;
                return userID;
            }

            else if (intID >= 1000 & intID < 10000)
            {
                apdTo = ap2 + Convert.ToString(intID);
                userID = apdTo;
                return userID;
            }

            else if (intID >= 10000 & intID < 100000)
            {
                apdTo = ap1 + Convert.ToString(intID);
                userID = apdTo;
                return userID;
            }

            else
            {
                userID = Convert.ToString(intID);
                return userID;
            }
        }
        /*
         @ function idIsUnique(idToCheck)
         * this is a function designed to ensure that the ID created in
           genUserID() is not already in use already in the system.
         * it does this by reading each line of the stored id's and if it finds
           said ID throwing an error
         * if it doesn't find said error and reaches a blank line the system
           returns true.
         */
        public static bool idIsUnique(string idToCheck)
        {
            bool IIU;

            StreamReader sr = new StreamReader("accountIdStorage.txt");
            string reader = sr.ReadLine();

            while (reader != null)
            {
                if (idToCheck == reader)
                {
                    IIU = false;
                    sr.Close();
                    return IIU;
                }

                else
                {
                    IIU = false;
                    reader = sr.ReadLine();
                }
            }
            IIU = true;
            sr.Close();
            return IIU;
        }
        /*
         @ function saveID(CID)
         * this is a function designed to save the newly created and validated userID to
           its appriopriate storage file
         * it also tells the user what their ID is with a message
         */
        public static void saveID(string CID)
        {
            string ID = CID;
            Console.Write("your account ID is |" + ID + "|");
            Console.ReadLine();
            using (StreamWriter sw = new StreamWriter("accountIdStorage.txt", true))
            {
                sw.WriteLine(ID);
                sw.Close();
            }
            using (StreamWriter sw = new StreamWriter("accountUserRecords.txt", true))
            {
                sw.WriteLine("AccountID: " + ID);
                sw.Close();
            }
        }
        /*
        @ function saveUserName(PUN)
        * this is a function designed to save the newly create userName to
          its appriopriate storage file
        */
        public static void saveUserName(string pUN)
        {
            string UN = pUN;
            using (StreamWriter sw = new StreamWriter("accountUserRecords.txt", true))
            {
                sw.WriteLine("UN: " + UN);
                sw.Close();
            }
        }
        /*
        @ function savePassword(PPW)
        * this is a function designed to save the newly create Password to
          its appriopriate storage file
        */
        public static void savePassword(string pPW)
        {
            string PW = pPW;
            using (StreamWriter sw = new StreamWriter("accountUserRecords.txt", true))
            {
                sw.WriteLine("PW: " + PW);
                sw.Close();
            }
        }
        public static void saveNames(string pFname, string pLname)
        {
            string fName = pFname;
            string Lname = pLname;
            using (StreamWriter sw = new StreamWriter("accountUserRecords.txt", true))
            {
                sw.WriteLine("first name: " + fName);
                sw.WriteLine("last name: " + Lname);
                sw.Close();
            }
        }
        /*
         @ function completeFile()
         * this is a function that simply appends ----------------------- to the end
           of a record to break up individual records within the textfile
         */
        public static void completeFile()
        {
            using (StreamWriter sw = new StreamWriter("accountUserRecords.txt", true))
            {
                sw.WriteLine("-----------------------");
                sw.Close();
            }
        }
    }
}
